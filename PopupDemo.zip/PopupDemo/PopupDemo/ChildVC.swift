//
//  ChildVC.swift
//  PopupDemo
//
//  Created by ALOK RANJAN TIWARI on 27/08/16.
//  Copyright © 2016 ALOK RANJAN TIWARI. All rights reserved.
//

import UIKit

class ChildVC: UIViewController {
  
  var callback : ((Any?) -> Void)?
  
  override func viewDidLoad() {
    super.viewDidLoad()
  }
  
  @IBAction func btnCancelAction(_ sender: UIButton) {
    
    dismisVC()
  }
  
  @IBAction func btnOkAction(_ sender: UIButton) {
    
    dismisVC()
  }
  
  func dismisVC(){
    if let callback = callback{
      callback(nil)
    }
    self.dismiss(animated: true, completion: nil)
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
  }
}
