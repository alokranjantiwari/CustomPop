
//
//  ParentVC.swift
//  PopupDemo
//
//  Created by ALOK RANJAN TIWARI on 27/08/16.
//  Copyright © 2016 ALOK RANJAN TIWARI. All rights reserved.
//

import UIKit

class ParentVC: UIViewController,OverLay {
  
  override func viewDidLoad(){
    super.viewDidLoad()
  }
  
  @IBAction func btnCustomPopupAction(_ sender: UIButton) {
    
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    let childVC = storyBoard.instantiateViewController(withIdentifier: "ChildVC") as! ChildVC
    
    childVC.callback = { value in
      self.dim(.out, speed: dimSpeed)
    }
    
    dim(.in, alpha: dimLevel, speed: dimSpeed)
    self.present(childVC, animated: true, completion: nil)
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
  }
}
